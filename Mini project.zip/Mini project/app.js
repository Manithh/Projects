let buttons = document.querySelectorAll("button");
let input = document.querySelector("input");

for (let button of buttons) {
    button.addEventListener("click", function (e) {
        let btnText = e.target.textContent; 
        if (btnText === "AC") { //captial letter....
            input.value = ""; // Clear input
        } else if (btnText === "=") {
            try {
                // Evaluate the input value safely
                input.value = eval(input.value); 
            } catch (err) {
                input.value = "Error"; // Display error for invalid expressions
            }
        } else {
            input.value += btnText; // Append button text to input
        }
    });
}